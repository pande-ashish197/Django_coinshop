from django.contrib import admin
from .models import Order


class OrderAdmin(admin.ModelAdmin):
    list_display = ['product', 'customer', 'order_date', 'product_price']


admin.site.register(Order, OrderAdmin)

from customermanagement.models import Registration
from django.core.mail import EmailMultiAlternatives
from django.utils.html import strip_tags
from django.template.loader import render_to_string
from products.models import Product


"""def send_email_for_customer(customer_id):
    customer_details = Registration.get_customer_details_by_id(customer_id)
    customer_email_id = customer_details.email_id
    subject = f"Your order has been successfully placed "
    message = f"Hi {customer_details.first_name},\n" \
              f"Thank you for shopping with CoinShop!\n" \
              f"Your order for the below item has been successfully placed. We will contact you soon for delivery.\n" \
              f"\n" \
              f"Thanks,\n" \
              f"Team CoinShop"
    send_mail(subject, message, 'pande.ashish198@gmail.com', [customer_email_id], fail_silently=False)
"""


def send_email(request, customer_id):
    customer_cart = request.session.get('cart').keys()
    product_details = Product.get_products_by_id(customer_cart)
    customer_details = Registration.get_customer_details_by_id(customer_id)
    customer_email_id = customer_details.email_id
    data = {
        'customer_details': customer_details,
        'product_details': product_details
    }
    html_content = render_to_string('orders_for_email.html', data)
    text_content = strip_tags(html_content)
    subject = f"Your order has been successfully placed "
    message = EmailMultiAlternatives(subject, text_content, 'pande.ashish198@gmail.com', [customer_email_id])
    message.attach_alternative(html_content, "text/html")
    message.send(fail_silently=False)




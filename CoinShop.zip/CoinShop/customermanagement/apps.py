from django.apps import AppConfig


class CustomermanagementConfig(AppConfig):
    name = 'customermanagement'

from django.apps import AppConfig


class CartmanagementConfig(AppConfig):
    name = 'cartmanagement'

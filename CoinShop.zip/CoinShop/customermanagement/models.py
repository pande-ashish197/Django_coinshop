from django.db import models


class Registration(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    email_id = models.EmailField()
    password = models.CharField(max_length=500)
    mobile_no = models.IntegerField()
    address1 = models.CharField(max_length=100)
    address2 = models.CharField(max_length=200)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)

    def __str__(self):
        full_name = self.first_name+" "+self.last_name
        return full_name

    @staticmethod
    def check_email_exists(email):
        try:
            return Registration.objects.get(email_id=email)
        except Exception as e:
            print("Error:", e)
            return False

    @staticmethod
    def get_customer_details_by_id(customer_id):
        return Registration.objects.get(id=customer_id)


    @staticmethod
    def save_updated_first_name(updated_first_name, customer_id):
        Registration.objects.filter(id=customer_id).update(first_name=updated_first_name)
        return True

    @staticmethod
    def save_updated_last_name(updated_last_name, customer_id):
        Registration.objects.filter(id=customer_id).update(last_name=updated_last_name)
        return True

    @staticmethod
    def save_updated_email(updated_email_id, customer_id):
        Registration.objects.filter(id=customer_id).update(email_id=updated_email_id)
        return True

    @staticmethod
    def save_updated_mobile_no(updated_mobile_no, customer_id):
        Registration.objects.filter(id=customer_id).update(mobile_no=updated_mobile_no)
        return True
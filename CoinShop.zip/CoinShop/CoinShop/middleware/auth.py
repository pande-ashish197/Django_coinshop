from django.shortcuts import redirect,HttpResponseRedirect


def authorize_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        returnURL = request.META['PATH_INFO']
        print(returnURL, type(returnURL))
        working_url = returnURL.rpartition('/')
        print(working_url)
        if not request.session.get('customer_id'):
            return HttpResponseRedirect(f'{working_url[0]}?return_url={returnURL}')
        response = get_response(request)
        return response
    return middleware

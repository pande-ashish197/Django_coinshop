from django.db import models
from products.models import Product
from customermanagement.models import Registration


class Order(models.Model):
    order_date = models.DateTimeField()
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    customer = models.ForeignKey(Registration, on_delete=models.CASCADE)
    product_price = models.FloatField(default=0)
    cart_total = models.FloatField(default=0)
    order_status = models.BooleanField(default=False)

    def save_order(self):
        self.save()

    @staticmethod
    def get_customer_by_id(customer_id):
        return Order.objects.filter(customer=customer_id).order_by('-order_date')

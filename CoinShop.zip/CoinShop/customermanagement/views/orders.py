from django.views import View
from django.shortcuts import render
from cartmanagement.models import Order
from CoinShop.middleware.auth import authorize_middleware
from django.utils.decorators import method_decorator


class CustomerOrders(View):
    @method_decorator(authorize_middleware)
    def get(self, request):
        customer_id = request.session.get('customer_id')
        order = Order.get_customer_by_id(customer_id)
        return render(request, 'orders.html', {'orders': order})

from django.shortcuts import render, redirect
from django.views import View
from products.models import Product
import datetime
from products.templatetags import cart
from .models import Order
from customermanagement.models import Registration
from models import SendEmail


class CartManagement(View):
    def get(self, request):
        print("session=", request.session)
        print(request.method)
        product_ids, product_details = cart.get_details(request)
        print(product_ids)
        print(product_details)
        return render(request, 'cart.html', {'cart': product_details})

    def post(self, request):
        customer_id = request.session.get('customer_id')
        if customer_id:
            print("cart post", request.method)
            product_ids, product_details = cart.get_details(request)
            # ordered_products = []
            for product in product_details:
                print(product, product.id, type(product.id))
                order = Order(order_date=datetime.datetime.now(),
                              product_id=product.id,
                              customer=Registration(id=customer_id),
                              product_price=product.price,
                              cart_total=cart.total_price_cart(product_details, request.session.get('cart'))
                              )
                order.save_order()
            SendEmail.send_email(request, customer_id)
            cart.clear_cart(request)
            return redirect('homepage')
        else:
            return redirect('login')

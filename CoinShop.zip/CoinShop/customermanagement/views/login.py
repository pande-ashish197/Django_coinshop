from django.shortcuts import render, redirect, HttpResponseRedirect
from customermanagement.models import Registration
from django.contrib.auth.hashers import check_password
from django.views import View


class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email_id = request.POST.get('emailsignin')
        password = request.POST.get('password1')
        customer = Registration.check_email_exists(email_id)
        if customer:
            if check_password(password, customer.password):
                request.session['customer_id'] = customer.id
                request.session['customer_email'] = customer.email_id
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
                return redirect('homepage')
            else:
                error_message = "Invalid EmailId or Password!!"
        else:
            error_message = "Email ID not registered."
        print(customer)
        print(email_id, password)
        return render(request, 'login.html', {"error": error_message})


def logout(request):
    print("loggingout")
    request.session.clear()
    return redirect('login')
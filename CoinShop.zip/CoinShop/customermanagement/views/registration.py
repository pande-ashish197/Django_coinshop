from django.shortcuts import render
from models.userregistration import user_registration
from django.views import View


class Registration(View):
    def get(self, request):
        return render(request, 'registration.html')

    def post(self, request):
        req = request
        req_post = request.POST
        return user_registration(req, req_post)

from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Product, Category
from django.views import View


class Index(View):
    def get(self, request):
        category_id = request.GET.get('category')
        products = Product.get_all_products_by_category_id(category_id)
        categories = Category.get_all_category()
        data = {'products': products,
                'categories': categories}
        return render(request, 'index.html', data)

    def post(self, request):
        print(request.method)
        product_id = request.POST.get('productid')
        print(product_id,   type(product_id))
        action = request.POST.get('Subtract')
        print(action, type(action))
        print("ProductID is:", product_id)
        cart = request.session.get('cart')
        print(cart)
        if cart:
            quantity = cart.get(product_id)
            print(f"Quantity of {product_id} is {quantity}")
            if quantity:
                if action and quantity > 0:
                    quantity -= 1
                    cart[product_id] = quantity
                    if quantity == 0:
                        print("Hello")
                        cart.pop(product_id)
                else:
                    cart[product_id] = quantity+1
            else:
                cart[product_id] = 1
        else:
            print("inside else block")
            cart = {product_id: 1}
        request.session['cart'] = cart
        print(cart)
        return redirect('homepage')
        #return HttpResponse(product_id)







def new(request):
    return HttpResponse("NewProducts")
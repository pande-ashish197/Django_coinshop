from django.views import View
from django.shortcuts import render
from customermanagement.models import Registration
from django.shortcuts import redirect


class AccountDetails(View):
    def get(self, request):
        customer_id = request.session.get('customer_id')
        print(customer_id)
        customer_details = Registration.get_customer_details_by_id(customer_id)
        print(customer_details.first_name)
        return render(request, 'customerdetails.html', {'customer': customer_details})

    def post(self, request):
        customer_id = request.session.get('customer_id')
        updated_first_name = request.POST.get('firstname')
        updated_last_name = request.POST.get('lastname')
        updated_email_id = request.POST.get('email')
        updated_mobile_no = request.POST.get('mobileno')
        current_password = request.POST.get('currentpassword')
        new_password = request.POST.get('newpassword')
        confirm_new_password = request.POST.get('confirmnewpassword')
        if updated_first_name:
            output = Registration.save_updated_first_name(updated_first_name, customer_id)
        elif updated_last_name:
            output = Registration.save_updated_last_name(updated_last_name, customer_id)
        elif updated_email_id:
            output = Registration.save_updated_email(updated_email_id, customer_id)
        elif updated_mobile_no:
            output = Registration.save_updated_mobile_no(updated_mobile_no, customer_id)

        if output:
            return redirect('customerdetails')

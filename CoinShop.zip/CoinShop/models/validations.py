from customermanagement.models import Registration


class UserFieldsValidation:
    def __init__(self, first_name, last_name, email_id, mobile_no, address1, address2, city):
        self.first_name = first_name
        self.last_name = last_name
        self.mobile_no = mobile_no
        self.email_id = email_id
        self.address1 = address1
        self.address2 = address2
        self.city = city
        self.error_messages = []

    def data_validation(self):
        #error_messages = []
        if not self.first_name:
            self.error_messages.append("First Name required!")
        elif len(self.first_name) > 32:
            self.error_messages.append("First Name is too long. Maximum length can be 32 characters.")

        if not self.last_name:
            self.error_messages.append("Last Name required!")
        elif len(self.last_name) > 32:
            self.error_messages.append("Last Name is too long. Maximum length can be 32 characters.")

        if not self.mobile_no:
            self.error_messages.append("Mobile number required!")
        elif len(self.mobile_no) < 10 or len(self.mobile_no) > 10:
            self.error_messages.append("Mobile number should be of 10 digits")

        if not self.address1:
            self.error_messages.append("Address required!")
        elif len(self.address1) > 100:
            self.error_messages.append("Address can be of 100 characters.")

        if not self.address2:
            self.error_messages.append("Address2 required!")
        elif len(self.address2) > 100:
            self.error_messages.append("Address2 can be of 100 characters.")

        if not self.city:
            self.error_messages.append("City required!")
        elif len(self.address2) > 28:
            self.error_messages.append("City can be of 28 characters.")
        print(self.error_messages)
        return self.error_messages

    def email_validation(self):
        #check_email = Registration()
        #isExists = check_email.check_emailexists(self.email_id)
        if Registration.check_email_exists(self.email_id):
            isExists = True
        else:
            isExists = False
        print(self.email_id, isExists)
        if len(self.email_id) < 15:
            self.error_messages.append("Email should be atleast 15 characters long")
        elif isExists:
            self.error_messages.append("Email already Registered!")




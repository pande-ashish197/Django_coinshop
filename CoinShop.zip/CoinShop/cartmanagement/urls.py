from django.urls import path
from .views import CartManagement


urlpatterns = [
    path('', CartManagement.as_view())
]

from customermanagement.models import Registration
from .validations import UserFieldsValidation
from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect


def user_registration(req, req_post):
    first_name = req_post.get('firstname')
    last_name = req_post.get('lastname')
    email_id = req_post.get('email')
    password = req_post.get('password')
    mobile_no = req_post.get('contact_no')
    address1 = req_post.get('address1')
    address2 = req_post.get('address2')
    city = req_post.get('city')
    state = req_post.get('state')
    values = {
        'first_name': first_name,
        'last_name': last_name,
        'email_id': email_id,
        'mobile_no': mobile_no,
        'address1': address1,
        'address2': address2,
        'city': city
    }
    validate_data = UserFieldsValidation(first_name, last_name, email_id, mobile_no, address1, address2, city)
    error = validate_data.data_validation()
    email_error = validate_data.email_validation()
    hashed_password = make_password(password)
    data = {
        'error': [error, email_error],
        'values': values
    }
    if error:
        return render(req, 'registration.html', data)
    else:
        r = Registration(first_name=first_name,
                         last_name=last_name,
                         email_id=email_id,
                         password=hashed_password,
                         mobile_no=mobile_no,
                         address1=address1,
                         address2=address2,
                         city=city,
                         state=state)
        r.save()
        return redirect("homepage")
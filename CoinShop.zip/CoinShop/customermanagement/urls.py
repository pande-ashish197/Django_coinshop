from django.urls import path
from customermanagement.views import registration, login, orders, accountdetails


urlpatterns = [
    path('', login.Login.as_view(), name="login"),
    path('account-creation', registration.Registration.as_view()),
    path('logout', login.logout, name="logout"),
    path('orders', orders.CustomerOrders.as_view(), name="customerorders"),
    path('userdetails', accountdetails.AccountDetails.as_view(), name='customerdetails')
]

from django import template
from products.models import Product

register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    t = str(product.id)
    if t in cart.keys() and cart.get(t) > 0:
        return True
    else:
        return False


@register.filter(name='cart_quantity')
def cart_quantity(product, cart):
    if is_in_cart(product, cart):
        return cart.get(str(product.id))
    else:
        return 0


@register.filter(name='total_price')
def total_price(product, cart):
    quantity = cart_quantity(product, cart)
    return quantity * product.price


@register.filter(name='total_price_cart')
def total_price_cart(products, cart):
    summation = 0
    for p in products:
        summation += total_price(p, cart)
    return ("%.2f"%(summation))


def get_details(request):
    product_ids = request.session.get('cart').keys()
    product_details = Product.get_products_by_id(product_ids)
    print("Product_id=", product_ids)
    print("Product_details=", product_details)
    return product_ids, product_details


@register.filter(name='total_products_in_cart')
def total_products_in_cart(cart):
    total = 0
    for items in cart.values():
        total += items
    return total


def clear_cart(request):
    print("Clear cart")
    cart = request.session.get('cart')
    for items in list(cart):
        cart.pop(items)
    request.session['cart'] = cart






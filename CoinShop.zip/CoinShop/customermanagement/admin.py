from django.contrib import admin
from .models import Registration


class RegistrationAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email_id',
                    'password', 'mobile_no', 'address1', 'address2', 'city', 'state')


admin.site.register(Registration, RegistrationAdmin)



